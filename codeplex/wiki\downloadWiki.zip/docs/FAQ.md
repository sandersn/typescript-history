# **FAQ**

#### Q: How can I download the latest official TypeScript release?
You can download TypeScript as an npm package or a Windows Installer file (msi) from the [Downloads](http://typescript.codeplex.com/releases) page.

#### Q: What is the official TypeScript website?
You can find us on the internet at [http://www.typescriptlang.org](http://www.typescriptlang.org).

#### Q: How do I contribute to TypeScript?
For information on contributing, see [How to Contribute to TypeScript](contribute).

#### Q: Can I incorporate TypeScript into my application?
TypeScript is released under the [open source Apache 2.0 license](http://typescript.codeplex.com/license).  Any use allowed under that license is perfectly okay.
