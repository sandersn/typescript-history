# Getting Started

* [Basic Types](Basic-Types-in-TypeScript) 
* [Interfaces](Interfaces-in-TypeScript) 
* [Classes](Classes-in-TypeScript) 
* [Modules](Modules-in-TypeScript) 
* [Functions](Functions-in-TypeScript) 
* [Generics](Generics-in-TypeScript) 
* [Common Errors](Common-Errors)

# Advanced Topics

* [Mixins](Mixins-in-TypeScript) 
* [Declaration Merging](Declaration-Merging) 
* [Type Inference](Type-Inference-in-TypeScript) 
* [Type Compatibility](Type-Compatibility-in-TypeScript)
* [Writing Definition (.d.ts) Files](Writing-Definition-(.d.ts)-Files)

