# Contributions We Accept
TypeScript is currently accepting contributions in the form of bug fixes. A bug must have an issue tracking it in the issue tracker that has been approved (Status = Active) by the TypeScript team. Your pull request should include a link to the bug that you are fixing. If you’ve submitted a PR for a bug, please post a comment in the bug to avoid duplication of effort.

Features (things that add new or improved functionality to TypeScript) may be accepted, but will need to first be approved (marked as “Answered” by a TypeScript coordinator with the message “Approved”) in the Contribution Discussions forum. Please include {"[feature](feature)"} in the title of your forum post. Features with language design impact, or that are adequately satisfied with external tools, will not be accepted.

Design changes will not be accepted at this time. If you have a design change proposal, please post it to the Language Specification forum.

# Legal
You will need to complete a Contributor License Agreement (CLA). Briefly, this agreement testifies that you are granting us permission to use the submitted change according to the terms of the project’s license, and that the work being submitted is under appropriate copyright.

Please submit a Contributor License Agreement (CLA) before submitting a pull request . Download the agreement (docx: [Microsoft Contribution License Agreement.docx](Guidelines for Contributors_Microsoft Contribution License Agreement.docx), pdf: [Microsoft Contribution License Agreement.pdf](Guidelines for Contributors_Microsoft Contribution License Agreement.pdf)), sign, scan, and email it back to cla@microsoft.  Be sure to include your **CodePlex user name** along with the agreement. Once we have received the signed CLA, we’ll review the request. Please note that we’re currently only accepting pull requests of bug fixes rather than new features.

# Housekeeping
Your pull request should:
* Include a description of what your change intends to do
* Be a child commit of a reasonably recent commit in the **develop** branch
	* Requests need not be a single commit, but should be a linear sequence of commits (i.e. no merge commits in your PR)
* It is desirable, but not necessary, for the tests to pass at each commit
* Have clear commit messages
	* e.g. “Refactor _feature_”, “Fix _issue_”, “Add tests for _issue_”
* Include adequate tests
	* At least one test should fail in the absence of your non-test code changes. If your PR does not match this criteria, please specify why.
	* See [Creating a TypeScript Compiler Test](Creating-a-TypeScript-Compiler-Test) and [Writing TypeScript Language Service Tests](Writing-TypeScript-Language-Service-Tests) for documentation on creating tests
	* Tests should include reasonable permutations of the target fix/change
	* Include baseline changes with your change
	* All changed code must have 100% code coverage
* Follow the existing code conventions in the file
