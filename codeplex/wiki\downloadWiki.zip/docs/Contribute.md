# **How to Contribute to TypeScript**
If you would like to contribute, consider these options:
* [Contribute bug fixes](https://typescript.codeplex.com/wikipage?title=Guidelines%20for%20Contributors). This includes information on the Contributor License Agreement (or CLA)
* Discuss the language specification ([docx](http://go.microsoft.com/fwlink/?LinkId=267121), [pdf](http://go.microsoft.com/fwlink/?LinkId=267238)) in the TypeScript [discussion forum](http://typescript.codeplex.com/discussions/topics/5488/language-specification).
* Review [code checkins](http://typescript.codeplex.com/SourceControl/list/changesets) and [send feedback](http://typescript.codeplex.com/discussions/topics/5489/code-checkins). (The **[develop](http://typescript.codeplex.com/SourceControl/list/changesets?branch=develop)** branch has the latest changes.)
* Submit a [bug report](http://typescript.codeplex.com/WorkItem/Create) (for a guide on submitting good bug reports, read [Painless Bug Tracking](http://www.joelonsoftware.com/articles/fog0000000029.html)). 
* Help answer questions on [StackOverflow](http://stackoverflow.com/questions/tagged/typescript).
* Join the [#typescript](http://twitter.com/#!/search/realtime/%23typescript) discussion on Twitter.
* Tell others about the project. 
