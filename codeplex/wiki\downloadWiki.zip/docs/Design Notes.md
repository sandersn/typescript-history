Current Design Notes:
* [Design Notes: Enums](Design-Notes_-Enums)
* [Design Notes: Overloading on Constants](Design-Notes_-Overloading-on-Constants)
* [Design Notes: Generics](Design-Notes_-Generics)
* [Design Notes: Boolean vs Bool](Design-Notes_-Boolean-vs-Bool)
* [Design Notes: Fundules, Clodules, and Mixins](Design-Notes_-Fundules,-Clodules,-and-Mixins)
* [Design Notes: 'this' Typing](Design-Notes_-'this'-Typing)