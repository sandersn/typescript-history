# TypeScript 0.9.5 beta

You can get the beta for the upcoming 0.9.5 release [here](http://download.microsoft.com/download/2/F/F/2FFA1FBA-97CA-4FFB-8ED7-A4AE06398948/TypeScriptSetup.0.9.5.beta.exe).  This release is focused on memory usage, reliability, and better spec conformance.  We'd like to get your feedback on how the beta works for your project before we release 0.9.5.

**Note:** please read the [breaking change notices](https://typescript.codeplex.com/wikipage?title=Known%20breaking%20changes%20between%200.8%20and%200.9&referringTitle=Documentation) as there have been breaking changes between 0.9.1.1 and 0.9.5 that may affect your code.

