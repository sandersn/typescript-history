# **TypeScript Roadmap**

TypeScript is now a 1.0 language that's supported cross-platform across Visual Studio, NPM, and as a set of JavaScript sources that are compatible with most JavaScript engines.  This roadmap describes the upcoming plans for the TypeScript language and tools.

_Please note:_ This is informational only.  The roadmap below is subject to change.  

## 1.0
* Start of backward compatibility begins
* Visual Studio in-box support begins

## 1.0.1
* Bugfixes to address issues in the 1.0 release

## "2.0" (note: no version number has yet been assigned to this work)
* Align with [ECMAScript 6](ECMAScript-6-Status)
* ECMAScript 6 output mode
* Investigate top-rated feature requests (protected, mixins, abstract classes, etc).  
* Investigate async/await as a desugaring to ES6
* Improve lib.d.ts modularity
