Currently, "boolean" is the correct name of the type when inspected in JavaScript, but our type is called "bool".  Should we switch?

* We make the breaking change, but keep bool for awhile
