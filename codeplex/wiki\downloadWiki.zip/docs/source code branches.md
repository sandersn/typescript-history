# Source Code Branches
TypeScript development happens across multiple branches or forks (inspired by an article on [effective git branching](http___nvie.com_posts_a-successful-git-branching-model_)).  The main three branches are: 
* **'master'**  This branch tracks the changesets of the released versions.
* **'develop'**  This branch tracks the cutting edge shared among developers and may be unstable.
* **'release-x.x'**  Each release branch tracks what is expected to be part of a particular release.  Checkins to a release branch are largely to stabilize the branch in preparation for a release.
Other experimental work is done on separate forks, which can be found through the CodePlex site under "Forks" in the Source Code tab.