_**Please note:** This page is a work-in-progress. It may have errors and is subject to change._

# Introduction

As applications grow from a single source file to multiple source files, you'll need to allow these source files to see each other's declarations.  There are three ways that source files can see each other during commandline compilation: if you pass the source files together on the commandline in one call to the compiler, use the 'import ... = require(...)' statement, or if you use the ///<reference path=..">form.  The last of the three, sometimes called "triple slash references", is a hint to the compiler that source from another file will be available at runtime.  In this article, we'll focus on triple slash references and how to use them.

# References



# References and --out

# Visual Studio and References