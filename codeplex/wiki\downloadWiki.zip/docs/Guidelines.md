# **Project Guidelines**

## Creating New Issues
Please follow the following guidelines when creating new bugs in the [Issue Tracker](http://typescript.codeplex.com/workitem/list/basic). (See also [Painless Bug Tracking](http://www.joelonsoftware.com/articles/fog0000000029.html).)
* Search the Issue Tracker to see if the bug has already been reported.
* Use a descriptive title that identifies the bug.
* Provide a detailed description of the bug. 
* Describe the expected behavior and the actual behavior. 
* Attach a simple project that can be built and run to reproduce the bug. 
* Include any relevant error messages and stack traces. 
* Attach any relevant log or trace files.
* Subscribe to notifications for the created issue in case there are any follow up questions. 

## Triage Process
We'll be using the following process to triage bugs in the [Issue Tracker](http://typescript.codeplex.com/workitem/list/basic):
# New bugs are opened with the **Proposed** state. 
#  During triage, we'll assign bugs to a specific release or to the backlog for future work. We'll also assign a developer. 
# Once the bug fix has been submitted, the developer will change the status to **Fixed** and assign it to **Unassigned**.
# The person who opened the bug should verify the fix, and mark it as **Closed**. Our QA team will also verify the bug fix. 
We will run regular triage meetings with the project team. If there is a bug you feel strongly about but it hasn’t yet been triaged, please start a [discussion](http://typescript.codeplex.com/discussions).
