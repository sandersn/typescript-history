TypeScript uses a large set of compiler testcases to detect unexpected changes in the compiler behavior.

# Running the Tests
To run all tests, invoke the {{runtests}} target using jake:
{{
jake runtests
}}

This will also include language service tests; to run only the compiler tests, add the flag:
{{
jake runtests tests=--compiler
}}

# Adding a Test
To add a new testcase, simply place a .ts file in {{tests\cases\compiler}} containing code that exemplifies the bugfix or change you are making.

These files support metadata tags in the format {{ // @name: value }}. The supported names and values are:
 * {{comments}}, {{sourcemap}}, {{noimplicitany}}, {{declaration}}: {{true}} or {{false}} (corresponds to the compiler command-line options of the same name)
 * {{target}}: {{ES3}} or {{ES5}} (same as compiler)
 * {{out}}, {{outDir}}: _path_ (same as compiler)
 * {{module}}: {{local}}, {{commonjs}}, or {{amd}} ({{local}} corresponds to not passing any compiler {{--module}} flag)

Note that if you have a test corresponding to a specific spec compliance item, you can place it in {{tests\cases\conformance}} in an appropriately-named subfolder. Note that filenames here must be distinct from all other compiler testcase names, so you may have to work a bit to find a unique name if it’s something common.

# Managing the Baselines
Compiler testcases generate baselines that track the emitted .js, the errors produced by the compiler, and the type of each expression in the file. Additionally, some testcases opt in to baselining the source map output.

When a change in the baselines is detected, the test will fail and a diff will be written to the file {{baseline-report.html}}. After verifying that the changes in the baselines are correct, run
{{
jake baseline-accept
}}
to establish the new baselines as the desired behavior. This will change the files in {{tests\baselines\reference}}, which should be included as part of your commit. It's important to carefully validate changes in the baselines.

Note that {{baseline-accept}} should only be run after a full test run! Accepting baselines after running a subset of tests will delete baseline files for the tests that didn't run.