# Acknowledgements

TypeScript wouldn't be the tool that it is today without the tireless work of the TypeScript community.  This page is our big "thank you!" the community as a whole and a place where we recognize individuals that have gone above and beyond to help make TypeScript a better project.

* [nabog](http://www.codeplex.com/site/users/view/nabog)
* [jrieken](http://www.codeplex.com/site/users/view/jrieken)
* [BBGONE](http://www.codeplex.com/site/users/view/BBGONE)
* [derekcicerone](http://www.codeplex.com/site/users/view/derekcicerone)
* [fsoikin](http://www.codeplex.com/site/users/view/fsoikin)
* [mihailik](http://www.codeplex.com/site/users/view/mihailik)
* [constexpr](http://www.codeplex.com/site/users/view/constexpr)
* [clausreinke](http://www.codeplex.com/site/users/view/clausreinke)
* [Hesselink](http://www.codeplex.com/site/users/view/Hesselink)
* [schungx](http://www.codeplex.com/site/users/view/schungx)
* [WilliamMoy](http://www.codeplex.com/site/users/view/WilliamMoy)
* [kayahr](http://www.codeplex.com/site/users/view/kayahr)

