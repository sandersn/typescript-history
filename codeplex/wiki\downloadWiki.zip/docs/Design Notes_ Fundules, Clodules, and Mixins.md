## 10/19/2012

Fundules, clodules and lightweight mixins.  Motivations:
* Properties on functions
	* function foo() {}
	* foo.data = "hello";
* Nested classes
	* class Geometry {}
	* class Geometry.Point extends Geometry {}
* Namespace interfaces
	* interface jQuery.AjaxSettings {}
* Concepts in TS: (T: Types, N: Namespace, P: Properties)
	* Interfaces
		* T
	* Modules
		* N & T & P
	* Classes
		* T & P
	* Functions
		* P
	* Variables
		* P
* Names can be:
	* Types
		* Things that can go after colon
	* Namespaces:
		* Things that can contain namespaces or types
		* N.N.N.T
	* Properties
		* Things that are in the value scope referring to things at runtime
		* P.P.P.P

* Proposal:
	* Module, classes, funciton can all contribute to the same name
	* If only 'module' definitions contribute to a name, it can be spread across files
	* If any class and/or function definition contributes to a name, all contributions must be in the same file
	* Allow dotted named declarations
		* function x.y(…)
	* Consider:  When we know a name exists, don't generate the potential creation code
	* Bring back anonymous modules??
	* Brands
		* Provide:
		* Know it was created by your constructor
			* This isn't that important
		* Captures knowledge of privates
			* This is partly handled for free given privates as members of the type
			* But need to make sure privates have unique names (GUID attached)
* Summary?
	* Namespacing types
	* Extending functions/classes with modules
	* Getting rid of brands
	* Open ended classes
	* Anonymous modules

* Examples:
{code:javascript}
interface jQuery {
}
module jQuery {
    interface XHR { … }
}
var jQuery: …;
{code:javascript}
{code:javascript}
// IIFE
module {
   // 1000 lines of code

   class Bar implements SignalR { }
   export interface SignalR {}
   export interface $ {
       signalR: SignalR;
   }
   $.signalR = new Bar();
			
}
{code:javascript}

## 10/26/2012

* What should rules be for functions assigned to object types
* Rule for "var foo.data = 3;":
	* Permitted only if foo declared in same statement block
	* Any scope, even where a "module" isn't allowed - so this works:
{code:javascript}
var baz = (function() {
    function bar() { return 3;}
    var bar.data = 4;
    return bar;
})()
{code:javascript} 
* Examples:
	* var Foo.origin = ...;	
		* Foo.origin = ...;
	* function Foo.helper() {}
		* Foo.helper = function helper() {}
	* class Foo.Bar {}
		* Foo.Bar = (function() {
		*    function Bar() {}
		*    return Bar;
		* })() 
		
* 0th: Already supported, always
	* module F.x {}
* 1st: Class and function declarations F can, in the same scope, be augmented using:
	* var F.x;
	* class F.x {}
	* function F.x() {}
	* NOT module F.x {}
* 2nd: Interfaces can have dotted names which 
	* interface F.x {}
* 3rd: interface + class is allowed (this is lightweight mixins, need to look at motivating examples)
	* class F {}; interface F {}
