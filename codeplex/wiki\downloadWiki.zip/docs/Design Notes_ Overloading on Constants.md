## 12/7/2012
* Can specify a string literal in place of a type name (for a parameter).
{code:javascript}
	interface Foo {
	   createElement(name: string, options?: Stuff): Element;
	   createElement(name: 'div', options?: DivStuff): HTMLDivElement;
	   createElement(name: 'img'): HTMLImageElement;
	}
	
	var s = 'img';
	createElement(s) // ambiguous unless the string overload added above
	
	class Bar implements Foo {
	  createElement(name: string): Element {
	    if(name === 'div') return new HTMLDivElement();
	    if(name === 'img') return new HTMLImageElement();
	    else return new HTMLCustomElement();
	  }
	}
	
	var f: (s: 'hello') => void  = function(s: string) {}; // invalid
	var f: { (s: 'hello'): void } = function(s: string) {}; // invalid
{code:javascript}	
* Any overloaded signature that includes at least one string literal is a 'specialized signature'
* Each specialized signature must be assignment compatible to at least one non-specialized signature
* Specialized signatures are ignored for assignment compatibility to the type
* Overload resolution rules need to handle string literals
* Contextual typing always uses only the non-specialized overloads
