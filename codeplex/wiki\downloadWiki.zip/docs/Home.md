# We have moved!

We've heard your feedback and are moving to [GitHub](https://github.com/Microsoft/TypeScript) .  Please see the related [blog post](http://blogs.msdn.com/b/typescript/archive/2014/07/21/new-compiler-and-moving-to-github.aspx) for more information.