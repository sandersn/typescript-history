# 'this' Typing

What if we allowed 'this' to also act as a type to reflect the current type of this.  
{code:javascript}
class C {
  f() {
    var x: this; 
    var c: C;
    c = x;
  }
}
{code:javascript}

In short, we would enforce:

this <: C

Which would make the above:
{code:javascript}
class C<this extends C> {
  f() {
    var x: this; 
    var c: C;
    c = x;
  }
}
{code:javascript}

The subtype relationship would also disallow 'this' to be interchanged with the class type.  This example would not be allowed:
{code:javascript}
class C<this extends C> {
  f() {
    var x = this;
    x = new C(); 
  }
}
{code:javascript}
because C is not assignment compatible with x, because x : this.
