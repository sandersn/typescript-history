# Aligning with ECMAScript 6

This page lists the know current status for aligning with the ECMAScript 6 standard in the version of TypeScript currently in development.  

|| Feature || Status || Polyfill? || Notes ||
| arrow functions | Complete? | Yes | Need to investigate final ES6 design for deltas |
| let | | No | Polyfill would require techniques that would make the code less readable.  Currently leaning towards no polyfill.  |
| const | | No | |
| default function params | Complete? | Yes | Need to investigate final ES6 design for deltas |
| rest parameters | Complete? | Yes | Need to investigate final ES6 design for deltas |
| spread call operator | | ? | Need to investigate polyfill story |
| spread array operator | | ? | Need to investigate polyfill story |
| classes | | Yes | ES6 allows extending from expressions, which TS does not currently support |
| class expressions | | | | |
| computed properties | | No | |
| Privates in ES6 | | | Need to understand implications of outputting privates as symbols in ES6 output |
| symbols | | No | |
| well-typed-ness for well-known symbols| | No | |
| modules | | | |
| for...of loops | | | |
| array comprehensions | | Yes | |
| generator comprehensions | | | |
| iterators | | | |
| generators | | | |
| template strings | | Yes | Type can be based on the usage of each tagged template function |
| regexp 'y' flag | | No | |
| Map | Complete | | |
| Set | Complete | | |
| WeakMap | Complete | | |
| WeakSet | | | |
| Proxy | | | |
| destructuring | | | Depends on implementation.  We could introduce tuple types to improve typing |
| promises | | | |

